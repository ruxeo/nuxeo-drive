"""
PyQt related stuff should be grouped here to ease upgrades (PyQt5 -> PyQt6, etc.).
"""
