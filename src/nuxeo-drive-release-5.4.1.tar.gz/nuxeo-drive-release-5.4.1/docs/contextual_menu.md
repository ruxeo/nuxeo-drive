# GNU/Linux

## Nautilus

*Not up-to-date*

Install Nautilus required addon:

    apt-get install python-nautilus

Install the extension:

    cp tools/linux/resources/nautilus/contextual_menu.py ~/.local/share/nautilus-python/extensions

# macOS

Automatically handled at installation.

# Windows

Automatically handled at installation.
