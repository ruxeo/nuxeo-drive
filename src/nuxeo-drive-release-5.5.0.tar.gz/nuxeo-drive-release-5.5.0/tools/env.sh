# shellcheck shell=bash
# Where to store binaries on the packages server
export REMOTE_PATH_PROD="/var/www/community.nuxeo.com/static/drive-updates"
export REMOTE_PATH_STAGING="/var/www/community.nuxeo.com/static/drive-staging"
